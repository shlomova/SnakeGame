#ifndef  __COOP_MATH_UTILS_H__
#define __COOP_MATH_UTILS_H__

#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))

#endif // ! __COOP_MATH_UTILS_H__
