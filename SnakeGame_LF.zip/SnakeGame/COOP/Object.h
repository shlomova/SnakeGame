#ifndef __COOP_OBJECT__H_
#define __COOP_OBJECT__H_

#include "ExportDefs.h"
#include "ObjectBaseStructs.h"
#include "ClassDefMacros.h"
#include "InheritenceDefMacros.h"
#include "VirtualFuncCalling.h"
#include "ObjectLifecycleManagement.h"

#endif