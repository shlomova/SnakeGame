#include "UnitTestsInfra.h"

#include <stdio.h>
#include <stdarg.h>

const char* out_file_path = "results.json";
int __NUM_TESTED_CLASSES__ = 0;
double __ACCAMULATED_SUITES_GRADE__ = 0;

void double_print(FILE* f, const char* const format, ...) {
	va_list args;

	// Start variadic arguments processing for printf
	va_start(args, format);
	vprintf(format, args);
	va_end(args);
	if (f) {
		// Start variadic arguments processing for fprintf
		va_start(args, format);
		vfprintf(f, format, args);
		va_end(args);
	}
}


double my_ceil(double num) {
	int int_part = (int)num;
	if (num > 0 && num != int_part) {
		return int_part + 1;
	}
	else {
		return int_part;
	}
}

