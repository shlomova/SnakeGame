#ifndef __UNIT_TESTS_INFRA__
#define __UNIT_TESTS_INFRA__

#include <stdbool.h>
#include <stdio.h>
#include "UnitTestsInfra.h"
#include "ObjectLifecycleManagement.h"
#include "MathUtils.h"

//////////////////////////////////////////////////////////////
/// in the H file:
#define TESTS_LINKED_LIST_TYPE(SUITE_NAME) __single__test_link ##SUITE_NAME ##_t_

#define DEF_TEST_SUITE(SUITE_NAME)\
DEF_CLASS(SUITE_NAME);\
END_DEF(SUITE_NAME);  \
					  \
FUNCTIONS(SUITE_NAME);\
struct TESTS_LINKED_LIST_TYPE(SUITE_NAME) {								\
	int (*_test_func)(SUITE_NAME* _this, int* __is_fail__);		\
	char* name;												\
	struct TESTS_LINKED_LIST_TYPE(SUITE_NAME)* next;						\
}__tests_anchor;											\
MEM_FUN_DECL(SUITE_NAME, __run_all_tests__, struct TESTS_LINKED_LIST_TYPE(SUITE_NAME)* tests_anchor, int* num_passed, int* num_failed)

#define TEST_LINK_NAME(test_name) __ ##test_name ##__LINK_
#define TESTS_ANCHOR(SUITE_NAME) (SUITE_NAME ##VTable.__tests_anchor)

#define ADD_TEST(SUITE_NAME, TEST_NAME)\
MEM_FUN_DECL(SUITE_NAME, TEST_NAME, int * __is_fail__);\
struct TESTS_LINKED_LIST_TYPE(SUITE_NAME) TEST_LINK_NAME(TEST_NAME)

#define END_TEST_SUITE(SUITE_NAME)\
END_FUNCTIONS(SUITE_NAME);

//////////////////////////////////////////////////////////////
/// in the C file:
#define TEST_FUN_IMPL(SUITE_NAME, test_name)\
MEM_FUN_IMPL(SUITE_NAME, test_name, int* __is_fail__)

extern const char * out_file_path;
extern int __NUM_TESTED_CLASSES__;
extern double __ACCAMULATED_SUITES_GRADE__;

void double_print(FILE* f, const char* const format, ...);
double my_ceil(double num);

#define INIT_TEST_SUITE_WITH_SPECIFIC_MEM_SPACE(SUITE_NAME, memSpaceType, memSpaceSize) \
DEF_CTOR(SUITE_NAME) { init_global_memory(memSpaceSize, memSpaceType); } END_CTOR; \
DEF_DTOR(SUITE_NAME) {} END_DTOR; \
MEM_FUN_IMPL(SUITE_NAME, __run_all_tests__, struct TESTS_LINKED_LIST_TYPE(SUITE_NAME)* tests_anchor, int* num_passed, int* num_failed)\
{\
	FILE *results_file = fopen(out_file_path, "a"); __NUM_TESTED_CLASSES__++;\
	double num_tests = 0;\
	for (struct TESTS_LINKED_LIST_TYPE(SUITE_NAME)* it = tests_anchor; it != NULL; it = it->next) { num_tests++;}\
	int gradePerTest = (int)my_ceil(100. / num_tests);\
	int totalGrade = 0;\
	\
	for (struct TESTS_LINKED_LIST_TYPE(SUITE_NAME)* it = tests_anchor; it != NULL; it = it->next) {\
		int is_fail = false;\
		int __INNER_FUNC_CALL_RET_VALUE__ = it->_test_func(_this, &is_fail);\
		bool is_throw = IN_THROWING_VALUE == __INNER_FUNC_CALL_RET_VALUE__;\
		if (is_throw) { is_fail = true; }\
		\
		double_print(results_file, "Comment :=>> %s::%s: %s. %d marks\n" , #SUITE_NAME, it->name, is_fail ? "failure" : "success", is_fail ? 0 : gradePerTest); \
		if (is_throw) {double_print(results_file, "<|-- \n %s \n --|>\n" , LAST_EXCEPTION_ERROR_MSG); } \
		totalGrade += is_fail ? 0 : gradePerTest; \
	}\
	__ACCAMULATED_SUITES_GRADE__ += totalGrade; \
	double_print(results_file, "Comment :=>> Grade for suite: %d\n", MIN(totalGrade, 100)); \
	fclose(results_file);\
}\
END_FUN; \
INIT_CLASS(SUITE_NAME); \
TESTS_ANCHOR(SUITE_NAME).next = NULL; \
BIND(SUITE_NAME, __run_all_tests__);

#define PREPARE_TO_RUN_TESTS() {\
	__NUM_TESTED_CLASSES__ = 0;	\
	__ACCAMULATED_SUITES_GRADE__ = 0;\
	FILE *results_file = fopen(out_file_path, "w"); \
	fclose(results_file); }


#define GIVE_FINAL_GRADE() { \
	FILE *results_file = fopen(out_file_path, "a");\
	__ACCAMULATED_SUITES_GRADE__ = my_ceil(__ACCAMULATED_SUITES_GRADE__ / MAX(1,__NUM_TESTED_CLASSES__)); \
	double_print(results_file, "Grade :=>> %d\n", (int)MIN(__ACCAMULATED_SUITES_GRADE__, 100.));\
	fclose(results_file); }


#define INIT_TEST_SUITE(SUITE_NAME)\
INIT_TEST_SUITE_WITH_SPECIFIC_MEM_SPACE(SUITE_NAME, HEAP_BASED_MEMORY, 10)


#define BIND_TEST(SUITE_NAME, test_name)\
BIND(SUITE_NAME, test_name);\
(V_TABLE_INSTANCE(SUITE_NAME).TEST_LINK_NAME(test_name))._test_func = SUITE_NAME ##VTable.test_name.inner_function;\
(V_TABLE_INSTANCE(SUITE_NAME).TEST_LINK_NAME(test_name)).name = #test_name;\
(V_TABLE_INSTANCE(SUITE_NAME).TEST_LINK_NAME(test_name)).next = (SUITE_NAME ##VTable.__tests_anchor).next;\
TESTS_ANCHOR(SUITE_NAME).next = &(SUITE_NAME ##VTable.TEST_LINK_NAME(test_name));

#define END_INIT_TEST_SUITE(SUITE_NAME)\
END_INIT_CLASS(SUITE_NAME);\

extern int __NUM_IMPORTED_CLASSES__;
#define IMPORT_TESTS(SUITE_NAME)\
FUN_IMPL(__run__all__tests ##SUITE_NAME)\
{\
	CREATE(SUITE_NAME, suite) CALL;\
	int num_passed = 0, num_failed = 0;\
	struct TESTS_LINKED_LIST_TYPE(SUITE_NAME)* anchor = TESTS_ANCHOR(SUITE_NAME).next;\
	MFUN(&suite, __run_all_tests__), anchor, & num_passed, & num_failed CALL;\
}END_FUN


#define RUN_TESTS(SUITE_NAME) __run__all__tests ##SUITE_NAME();

#define NTEST_ASSERT(x) if (!(x)) {*__is_fail__ = true; THROW_MSG(#x);}
#define EXPECT_THROW { int __exception_tester__ = 0; if (1) { TRY {

#define ASSERT_THROW __exception_tester__++; } CATCH {} END_TRY; } \
if (__exception_tester__ != 0) {*__is_fail__ = true; THROW_MSG("FAIL: exception was not thrown");} }

#endif