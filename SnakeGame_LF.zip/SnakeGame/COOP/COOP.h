#ifndef __COOP_COOP_H__
#define __COOP_COOP_H__

#include "Object.h"
#include "DynamicMemoryManagement.h"

#endif