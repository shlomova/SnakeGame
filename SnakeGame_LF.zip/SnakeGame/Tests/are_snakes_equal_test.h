#ifndef __are_snakes_equal__
#define __are_snakes_equal__

#include "UnitTestsInfra.h"
#include "COOP.h"

DEF_TEST_SUITE(are_snakes_equal_test);
ADD_TEST(are_snakes_equal_test, WhenOfLength_1_test);
ADD_TEST(are_snakes_equal_test, WhenOfLength_4_test);
ADD_TEST(are_snakes_equal_test, WhenNotEqual_OfLength_1_test);
ADD_TEST(are_snakes_equal_test, WhenNotEqual_OfLength_4_test);
END_TEST_SUITE(are_snakes_equal_test);

#endif