#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "snake.h"
#include "create_long_snake_test.h" 
#include "snake.h" 

TEST_FUN_IMPL(create_long_snake_test, Sanity)
{
	//arrange
	direction_t growth_directions[] = { LEFT,UP,UP,RIGHT };
	snake_t expected_snake = create_snake(10, 10);
	NTEST_ASSERT(expected_snake != NULL);
	grow_snake(&expected_snake, 1, LEFT);
	grow_snake(&expected_snake, 2, UP);
	grow_snake(&expected_snake, 3, UP);
	grow_snake(&expected_snake, 4, RIGHT);

	//act
	snake_t actual_snake = create_long_snake(10, 10, growth_directions, 4);
	NTEST_ASSERT(actual_snake != NULL);

	//assert
	bool result = are_snakes_equal(actual_snake, 5, expected_snake, 5);
	NTEST_ASSERT(result);

} END_FUN

INIT_TEST_SUITE(create_long_snake_test);
BIND_TEST(create_long_snake_test, Sanity);
END_INIT_TEST_SUITE(create_long_snake_test);
