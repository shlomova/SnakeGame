#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "snake.h"
#include "move_snake_test.h"
#include "snake.h" 

TEST_FUN_IMPL(move_snake_test, Sanity)
{
	//arrange
	direction_t growth_directions[2] = { UP,UP };
	snake_t actual_snake = create_long_snake(10, 10, growth_directions, 2);
	NTEST_ASSERT(actual_snake != NULL);
	//print_snake(actual_snake, 2);
	direction_t growth_directions_expected[2] = { RIGHT, UP };
	snake_t expected_snake = create_long_snake(9, 10, growth_directions_expected, 2);
	NTEST_ASSERT(expected_snake != NULL);
	//print_snake(expected_snake, 2);

	//act
	move_snake(expected_snake, 3, UP);

	//assert
	int result = are_snakes_equal(actual_snake, 3, expected_snake, 3);
	NTEST_ASSERT(result);
} {

} END_FUN


TEST_FUN_IMPL(move_snake_test, StudentTest_1) {

} END_FUN

TEST_FUN_IMPL(move_snake_test, StudentTest_2) {

} END_FUN

TEST_FUN_IMPL(move_snake_test, StudentTest_3) {

} END_FUN

TEST_FUN_IMPL(move_snake_test, StudentTest_4) {

} END_FUN

TEST_FUN_IMPL(move_snake_test, StudentTest_5) {

} END_FUN

TEST_FUN_IMPL(move_snake_test, StudentTest_6) {

} END_FUN



INIT_TEST_SUITE(move_snake_test);
BIND_TEST(move_snake_test, Sanity);
BIND_TEST(move_snake_test, StudentTest_1);
BIND_TEST(move_snake_test, StudentTest_2);
BIND_TEST(move_snake_test, StudentTest_3);
BIND_TEST(move_snake_test, StudentTest_4);
BIND_TEST(move_snake_test, StudentTest_5);
BIND_TEST(move_snake_test, StudentTest_6);
END_INIT_TEST_SUITE(move_snake_test);
