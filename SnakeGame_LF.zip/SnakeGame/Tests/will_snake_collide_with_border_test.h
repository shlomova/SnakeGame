#ifndef __COLLISION_WITH_BORDER_TESTS_H__
#define __COLLISION_WITH_BORDER_TESTS_H__

#include "UnitTestsInfra.h" 
#include "COOP.h"           

DEF_TEST_SUITE(collision_with_border_test);
ADD_TEST(collision_with_border_test, CollideWithBorderUp);
ADD_TEST(collision_with_border_test, CollideWithBorderDown);
ADD_TEST(collision_with_border_test, CollideWithBorderRight);
ADD_TEST(collision_with_border_test, CollideWithBorderLeft);
ADD_TEST(collision_with_border_test, WillNotCollide);
END_TEST_SUITE(collision_with_border_test);

#endif // __COLLISION_WITH_BORDER_TESTS_H__
