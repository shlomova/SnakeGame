#include "are_snakes_equal_test.h"
#include "can_snake_move_in_direction.h"
#include "collision_with_itself_test.h"
#include "create_long_snake_test.h"
#include "grow_snake_test.h"
#include "move_snake_test.h"
#include "will_snake_collide_with_border_test.h"
#include "will_snake_reach_food_on_next_move_test.h"
#include "run_snake_game.h"

IMPORT_TESTS(are_snakes_equal_test);
IMPORT_TESTS(can_snake_move_in_direction_test);
IMPORT_TESTS(collision_with_itself_test);
IMPORT_TESTS(create_long_snake_test);
IMPORT_TESTS(grow_snake_test);
IMPORT_TESTS(move_snake_test);
IMPORT_TESTS(collision_with_border_test);
IMPORT_TESTS(snake_reaches_food_test);
IMPORT_TESTS(run_snake_test);

int main() {

	init_global_memory(0, HEAP_BASED_MEMORY);
	PREPARE_TO_RUN_TESTS();
	RUN_TESTS(are_snakes_equal_test);
	RUN_TESTS(can_snake_move_in_direction_test);
	RUN_TESTS(collision_with_itself_test);
	RUN_TESTS(create_long_snake_test);
	RUN_TESTS(grow_snake_test);
	RUN_TESTS(move_snake_test);
	RUN_TESTS(collision_with_border_test);
	RUN_TESTS(snake_reaches_food_test);
	//RUN_TESTS(run_snake_test);
	GIVE_FINAL_GRADE();
	return 0;
}

