#include "can_snake_move_in_direction.h"
#include "snake.h"

TEST_FUN_IMPL(can_snake_move_in_direction_test, UpTest)
{
	//arrange
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	grow_snake(&snake, 1, DOWN);

	//act
	bool result = can_snake_move_in_direction(DOWN, UP);

	//assert
	NTEST_ASSERT(false == result);

} END_FUN

TEST_FUN_IMPL(can_snake_move_in_direction_test, DownTest)
{
	//arrange
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	grow_snake(&snake, 1, UP);

	//act
	bool result = can_snake_move_in_direction(UP, DOWN);
	//assert
	NTEST_ASSERT(false == result);


} END_FUN

TEST_FUN_IMPL(can_snake_move_in_direction_test, LeftTest)
{
	//arrange
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	grow_snake(&snake, 1, RIGHT);

	//act
	bool result = can_snake_move_in_direction(RIGHT, LEFT);
	//assert
	NTEST_ASSERT(false == result);


} END_FUN

TEST_FUN_IMPL(can_snake_move_in_direction_test, RightTest)
{
	//arrange
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	grow_snake(&snake, 1, LEFT);

	//act
	bool result = can_snake_move_in_direction(LEFT, RIGHT);
	//assert
	NTEST_ASSERT(false == result);


} END_FUN

INIT_TEST_SUITE(can_snake_move_in_direction_test);
BIND_TEST(can_snake_move_in_direction_test, UpTest);
BIND_TEST(can_snake_move_in_direction_test, DownTest);
BIND_TEST(can_snake_move_in_direction_test, LeftTest);
BIND_TEST(can_snake_move_in_direction_test, RightTest);
END_INIT_TEST_SUITE(can_snake_move_in_direction_test);
