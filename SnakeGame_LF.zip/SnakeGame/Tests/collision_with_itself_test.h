#ifndef __COLLISION_WITH_ITSELF_TESTS_H__
#define __COLLISION_WITH_ITSELF_TESTS_H__

#include "UnitTestsInfra.h"
#include "COOP.h"

DEF_TEST_SUITE(collision_with_itself_test);
ADD_TEST(collision_with_itself_test, WhenIndeedCollides);
ADD_TEST(collision_with_itself_test, WhenDoesNotCollide);
ADD_TEST(collision_with_itself_test, WhenCollidesInMiddleOfBody);
END_TEST_SUITE(collision_with_itself_test);

#endif // __COLLISION_WITH_ITSELF_TESTS_H__