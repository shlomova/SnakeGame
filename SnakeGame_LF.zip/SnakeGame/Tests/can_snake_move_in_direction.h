#ifndef __CAN_SNAKE_MOVE_IN_DIRECTION_TESTS_H__
#define __CAN_SNAKE_MOVE_IN_DIRECTION_TESTS_H__

#include "UnitTestsInfra.h"
#include "COOP.h"

DEF_TEST_SUITE(can_snake_move_in_direction_test);
ADD_TEST(can_snake_move_in_direction_test, UpTest);
ADD_TEST(can_snake_move_in_direction_test, DownTest);
ADD_TEST(can_snake_move_in_direction_test, LeftTest);
ADD_TEST(can_snake_move_in_direction_test, RightTest);
END_TEST_SUITE(can_snake_move_in_direction_test);

#endif // __CAN_SNAKE_MOVE_IN_DIRECTION_TESTS_H__
