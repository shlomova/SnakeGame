#ifndef __GROW_SNAKE_TESTS_H__
#define __GROW_SNAKE_TESTS_H__

#include "UnitTestsInfra.h" 
#include "COOP.h"           

DEF_TEST_SUITE(grow_snake_test);
ADD_TEST(grow_snake_test, WhenUP);
ADD_TEST(grow_snake_test, WhenDOWN);
ADD_TEST(grow_snake_test, WhenRIGHT);
ADD_TEST(grow_snake_test, WhenLEFT);
ADD_TEST(grow_snake_test, WhenSeveralTimes);
END_TEST_SUITE(grow_snake_test);

#endif // __GROW_SNAKE_TESTS_H__
