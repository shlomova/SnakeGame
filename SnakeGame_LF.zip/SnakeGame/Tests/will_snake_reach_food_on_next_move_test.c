#include <stdio.h>
#include <stdint.h>
#include "snake.h"
#include "will_snake_reach_food_on_next_move_test.h"
#include "snake.h"

TEST_FUN_IMPL(snake_reaches_food_test, WhenLeft)
{
	//arrange
	direction_t growth_directions_expected[2] = { DOWN, DOWN };
	snake_t snake = create_long_snake(10, 10, growth_directions_expected, 2);
	uint8_t food[2];
	food[0] = 9;
	food[1] = 12;
	//print_snake(snake, 3);
	//act
	bool result = will_snake_reach_food_on_next_move(snake, 3, food, LEFT);
	//assert
	NTEST_ASSERT(result);
} END_FUN

TEST_FUN_IMPL(snake_reaches_food_test, WhenRight)
{
	//arrange
	direction_t growth_directions_expected[2] = { DOWN, DOWN };
	snake_t snake = create_long_snake(10, 10, growth_directions_expected, 2);
	uint8_t food[2];
	food[0] = 11;
	food[1] = 12;
	//print_snake(snake, 3);

	//act
	bool result = will_snake_reach_food_on_next_move(snake, 3, food, RIGHT);
	//assert
	NTEST_ASSERT(result);
} END_FUN

TEST_FUN_IMPL(snake_reaches_food_test, WhenUp)
{
	//arrange
	direction_t growth_directions_expected[2] = { DOWN, LEFT };
	snake_t snake = create_long_snake(10, 10, growth_directions_expected, 2);
	uint8_t food[2];
	food[0] = 9;
	food[1] = 10;
	//print_snake(snake, 3);
	//act
	bool result = will_snake_reach_food_on_next_move(snake, 3, food, UP);
	//assert
	NTEST_ASSERT(result);
} END_FUN

TEST_FUN_IMPL(snake_reaches_food_test, WhenDown)
{
	//arrange
	direction_t growth_directions_expected[2] = { DOWN, DOWN };
	snake_t snake = create_long_snake(10, 10, growth_directions_expected, 2);
	uint8_t food[2];
	food[0] = 10;
	food[1] = 13;
	//print_snake(snake, 3);
	//act
	bool result = will_snake_reach_food_on_next_move(snake, 3, food, DOWN);
	//assert
	NTEST_ASSERT(result);
} END_FUN

INIT_TEST_SUITE(snake_reaches_food_test);
BIND_TEST(snake_reaches_food_test, WhenLeft);
BIND_TEST(snake_reaches_food_test, WhenRight);
BIND_TEST(snake_reaches_food_test, WhenUp);
BIND_TEST(snake_reaches_food_test, WhenDown);
END_INIT_TEST_SUITE(snake_reaches_food_test);
