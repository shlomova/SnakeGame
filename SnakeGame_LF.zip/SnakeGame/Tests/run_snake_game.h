#ifndef __RUN_SNAKE_TESTS_H__
#define __RUN_SNAKE_TESTS_H__

#include "UnitTestsInfra.h" 
#include "COOP.h"           

DEF_TEST_SUITE(run_snake_test);
ADD_TEST(run_snake_test, Sanity);
END_TEST_SUITE(run_snake_test);

#endif // __MOVE_SNAKE_TESTS_H__
