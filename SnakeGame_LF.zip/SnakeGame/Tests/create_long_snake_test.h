#ifndef __CREATE_LONG_SNAKE_TESTS_H__
#define __CREATE_LONG_SNAKE_TESTS_H__

#include "UnitTestsInfra.h" 
#include "COOP.h"           

DEF_TEST_SUITE(create_long_snake_test);
ADD_TEST(create_long_snake_test, Sanity);
END_TEST_SUITE(create_long_snake_test);

#endif // __CREATE_LONG_SNAKE_TESTS_H__
