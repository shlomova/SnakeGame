#include "grow_snake_test.h" 
#include "snake.h"

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

TEST_FUN_IMPL(grow_snake_test, WhenUP)
{
	//arrange:
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	uint8_t expected_x = 10, expected_y = 9;
	size_t snake_size;

	//act
	snake_size = grow_snake(&snake, 1, UP);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1);
	uint8_t actual_x = snake[1][0];
	uint8_t actual_y = snake[1][1];
	free_snake(snake, 2);

	//assert
	NTEST_ASSERT(actual_x == expected_x && actual_y == expected_y);
} END_FUN

TEST_FUN_IMPL(grow_snake_test, WhenDOWN)
{
	//arrange:
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	uint8_t expected_x = 10, expected_y = 11;
	size_t snake_size;

	//act
	snake_size = grow_snake(&snake, 1, DOWN);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1); uint8_t actual_x = snake[1][0];
	uint8_t actual_y = snake[1][1];
	free_snake(snake, 2);

	//assert
	NTEST_ASSERT(actual_x == expected_x && actual_y == expected_y);
} END_FUN

TEST_FUN_IMPL(grow_snake_test, WhenRIGHT)
{
	//arrange:
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	uint8_t expected_x = 11, expected_y = 10;
	size_t snake_size;

	//act
	snake_size = grow_snake(&snake, 1, RIGHT);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1); uint8_t actual_x = snake[1][0];
	uint8_t actual_y = snake[1][1];
	free_snake(snake, 2);

	//assert
	NTEST_ASSERT(actual_x == expected_x && actual_y == expected_y);

} END_FUN

TEST_FUN_IMPL(grow_snake_test, WhenLEFT)
{
	//arrange:
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	uint8_t expected_x = 9, expected_y = 10;
	size_t snake_size;

	//act
	snake_size = grow_snake(&snake, 1, LEFT);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1); uint8_t actual_x = snake[1][0];
	uint8_t actual_y = snake[1][1];
	free_snake(snake, 2);

	//assert
	NTEST_ASSERT(actual_x == expected_x && actual_y == expected_y);
} END_FUN

TEST_FUN_IMPL(grow_snake_test, WhenSeveralTimes)
{
	// arrange
	snake_t snake = create_snake(10, 10);
	NTEST_ASSERT(snake != NULL);
	uint8_t expected_snake[][2] = { {10,10},{9,10},{9,9},{9,8},{10,8} };
	size_t snake_size;

	//act 
	snake_size = grow_snake(&snake, 1, LEFT);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1);
	snake_size = grow_snake(&snake, snake_size, UP);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1);
	snake_size = grow_snake(&snake, snake_size, UP);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1);
	snake_size = grow_snake(&snake, snake_size, RIGHT);
	NTEST_ASSERT(snake != NULL);
	NTEST_ASSERT(snake_size > 1);

	// NTEST_ASSERT
	for (int i = 0; i < 5; i++)
	{
		for (int coord = 0; coord < 2; coord++) {
			NTEST_ASSERT(snake[i][coord] == expected_snake[i][coord])
		}
	}
} END_FUN

INIT_TEST_SUITE(grow_snake_test);
BIND_TEST(grow_snake_test, WhenUP);
BIND_TEST(grow_snake_test, WhenDOWN);
BIND_TEST(grow_snake_test, WhenRIGHT);
BIND_TEST(grow_snake_test, WhenLEFT);
BIND_TEST(grow_snake_test, WhenSeveralTimes);
END_INIT_TEST_SUITE(grow_snake_test);
