#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "collision_with_itself_test.h"
#include "snake.h"

TEST_FUN_IMPL(collision_with_itself_test, WhenIndeedCollides)
{
	//arrange
	direction_t direction[] = { UP,UP,RIGHT,DOWN,DOWN };
	snake_t snake = create_long_snake(10, 10, direction, 5);
	NTEST_ASSERT(snake != NULL);

	bool expected__will_collide = true;
	//act
	bool actual__will_collide = will_snake_collide_with_itself_on_next_move(snake, 6, LEFT);

	//assert
	NTEST_ASSERT(actual__will_collide == expected__will_collide);

} END_FUN

TEST_FUN_IMPL(collision_with_itself_test, WhenDoesNotCollide)
{
	//arrange
	direction_t direction[] = { UP,UP,RIGHT,DOWN,DOWN };
	snake_t snake = create_long_snake(10, 10, direction, 5);
	NTEST_ASSERT(snake != NULL);
	bool expected__will_collide = false;
	//act
	bool actual__will_collide = will_snake_collide_with_itself_on_next_move(snake, 6, RIGHT);

	//assert
	NTEST_ASSERT(actual__will_collide == expected__will_collide);

} END_FUN

TEST_FUN_IMPL(collision_with_itself_test, WhenCollidesInMiddleOfBody)
{
	//arrange
	direction_t direction[] = { UP,UP,UP,UP,RIGHT,DOWN,DOWN };
	snake_t snake = create_long_snake(10, 10, direction, 7);
	NTEST_ASSERT(snake != NULL);
	bool expected__will_collide = true;
	//act
	bool actual__will_collide = will_snake_collide_with_itself_on_next_move(snake, 8, LEFT);

	//assert
	NTEST_ASSERT(actual__will_collide == expected__will_collide);

} END_FUN

INIT_TEST_SUITE(collision_with_itself_test);
BIND_TEST(collision_with_itself_test, WhenIndeedCollides);
BIND_TEST(collision_with_itself_test, WhenDoesNotCollide);
BIND_TEST(collision_with_itself_test, WhenCollidesInMiddleOfBody);
END_INIT_TEST_SUITE(collision_with_itself_test);
