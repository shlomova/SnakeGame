#include "are_snakes_equal_test.h"
#include "snake.h"

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

TEST_FUN_IMPL(are_snakes_equal_test, WhenOfLength_1_test)
{
	//arrange
	snake_t snake_a = create_snake(10, 10);
	snake_t snake_b = create_snake(10, 10);
	NTEST_ASSERT(snake_a != NULL);
	NTEST_ASSERT(snake_b != NULL);
	bool expected = true;
	//act
	bool actual = are_snakes_equal(snake_a, 1, snake_b, 1);

	//assert
	NTEST_ASSERT(actual == expected);
}END_FUN

TEST_FUN_IMPL(are_snakes_equal_test, WhenOfLength_4_test)
{
	//arrange
	direction_t growth_directions[3] = { RIGHT,RIGHT,DOWN };
	snake_t snake_a = create_long_snake(10, 10, growth_directions, 3);
	snake_t snake_b = create_long_snake(10, 10, growth_directions, 3);
	NTEST_ASSERT(snake_a != NULL);
	NTEST_ASSERT(snake_b != NULL);
	bool expected = true;
	//act
	bool actual = are_snakes_equal(snake_a, 3, snake_b, 3);

	//assert
	NTEST_ASSERT(actual == expected);
}END_FUN

TEST_FUN_IMPL(are_snakes_equal_test, WhenNotEqual_OfLength_1_test)
{
	//arrange
	snake_t snake_a = create_snake(10, 10);
	snake_t snake_b = create_snake(10, 11);
	NTEST_ASSERT(snake_a != NULL);
	NTEST_ASSERT(snake_b != NULL);
	bool expected = false;

	//act
	bool actual = are_snakes_equal(snake_a, 1, snake_b, 1);

	//assert
	NTEST_ASSERT(actual == expected);
	
}END_FUN

TEST_FUN_IMPL(are_snakes_equal_test, WhenNotEqual_OfLength_4_test)
{
	//arrange
	direction_t growth_directions_1[3] = { RIGHT,RIGHT,DOWN };
	direction_t growth_directions_2[3] = { RIGHT,UP,LEFT };
	snake_t snake_a = create_long_snake(10, 10, growth_directions_1, 3);
	snake_t snake_b = create_long_snake(10, 10, growth_directions_2, 3);
	NTEST_ASSERT(snake_a != NULL);
	NTEST_ASSERT(snake_b != NULL);
	bool expected = false;
	//act
	bool actual = are_snakes_equal(snake_a, 3, snake_b, 3);

	//assert
	NTEST_ASSERT(actual == expected);
	
}END_FUN

INIT_TEST_SUITE(are_snakes_equal_test);
BIND_TEST(are_snakes_equal_test, WhenOfLength_1_test);
BIND_TEST(are_snakes_equal_test, WhenOfLength_4_test);
BIND_TEST(are_snakes_equal_test, WhenNotEqual_OfLength_1_test);
BIND_TEST(are_snakes_equal_test, WhenNotEqual_OfLength_4_test);
END_INIT_TEST_SUITE(are_snakes_equal_test);