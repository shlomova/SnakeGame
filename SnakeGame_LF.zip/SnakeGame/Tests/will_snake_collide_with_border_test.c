#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "snake.h"
#include "will_snake_collide_with_border_test.h"
#include "snake.h"

TEST_FUN_IMPL(collision_with_border_test, CollideWithBorderUp)
{
	//arrange
	snake_t snake = create_snake(56, 1);
	NTEST_ASSERT(snake != NULL);
	//act 
	bool result = will_snake_collide_border_on_next_move(snake, 1, UP);

	//assert
	NTEST_ASSERT(result);
} END_FUN

TEST_FUN_IMPL(collision_with_border_test, CollideWithBorderDown)
{
	//arrange
	snake_t snake = create_snake(46, GAME_HEIGHT - 1);
	NTEST_ASSERT(snake != NULL);

	//act 
	bool result = will_snake_collide_border_on_next_move(snake, 1, DOWN);
	//assert
	NTEST_ASSERT(result);
} END_FUN

TEST_FUN_IMPL(collision_with_border_test, CollideWithBorderRight)
{
	//arrange
	snake_t snake = create_snake(GAME_WIDTH - 1, 12);
	NTEST_ASSERT(snake != NULL);

	//act 
	bool result = will_snake_collide_border_on_next_move(snake, 1, RIGHT);
	//assert
	NTEST_ASSERT(result);
} END_FUN

TEST_FUN_IMPL(collision_with_border_test, CollideWithBorderLeft)
{
	//arrange
	snake_t snake = create_snake(1, 42);
	NTEST_ASSERT(snake != NULL);

	//act 
	bool result = will_snake_collide_border_on_next_move(snake, 1, LEFT);
	//assert
	NTEST_ASSERT(result);
} END_FUN

TEST_FUN_IMPL(collision_with_border_test, WillNotCollide)
{
	//arrange
	snake_t snake = create_snake(78, 78);
	NTEST_ASSERT(snake != NULL);

	//act 
	bool result = will_snake_collide_border_on_next_move(snake, 1, DOWN);
	//assert
	NTEST_ASSERT(false == result);
} END_FUN

INIT_TEST_SUITE(collision_with_border_test);
BIND_TEST(collision_with_border_test, CollideWithBorderUp);
BIND_TEST(collision_with_border_test, CollideWithBorderDown);
BIND_TEST(collision_with_border_test, CollideWithBorderRight);
BIND_TEST(collision_with_border_test, CollideWithBorderLeft);
BIND_TEST(collision_with_border_test, WillNotCollide);
END_INIT_TEST_SUITE(collision_with_border_test);
