#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "snake.h"
#include "run_snake_game.h"
#include "snake.h" 
#include "snake_game_runner.h"

TEST_FUN_IMPL(run_snake_test, Sanity)
{
	run_snake_game();

} END_FUN

INIT_TEST_SUITE(run_snake_test);
BIND_TEST(run_snake_test, Sanity);
END_INIT_TEST_SUITE(run_snake_test);
