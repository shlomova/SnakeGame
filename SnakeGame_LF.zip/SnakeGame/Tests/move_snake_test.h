#ifndef __MOVE_SNAKE_TESTS_H__
#define __MOVE_SNAKE_TESTS_H__

#include "UnitTestsInfra.h" 
#include "COOP.h"           

DEF_TEST_SUITE(move_snake_test);
ADD_TEST(move_snake_test, Sanity);
ADD_TEST(move_snake_test, StudentTest_1);
ADD_TEST(move_snake_test, StudentTest_2);
ADD_TEST(move_snake_test, StudentTest_3);
ADD_TEST(move_snake_test, StudentTest_4);
ADD_TEST(move_snake_test, StudentTest_5);
ADD_TEST(move_snake_test, StudentTest_6);
END_TEST_SUITE(move_snake_test);

#endif // __MOVE_SNAKE_TESTS_H__
