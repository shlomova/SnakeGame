#ifndef __SNAKE_REACHES_FOOD_TESTS_H__
#define __SNAKE_REACHES_FOOD_TESTS_H__

#include "UnitTestsInfra.h"
#include "COOP.h"          

DEF_TEST_SUITE(snake_reaches_food_test);
ADD_TEST(snake_reaches_food_test, WhenLeft);
ADD_TEST(snake_reaches_food_test, WhenRight);
ADD_TEST(snake_reaches_food_test, WhenUp);
ADD_TEST(snake_reaches_food_test, WhenDown);
END_TEST_SUITE(snake_reaches_food_test);

#endif // __SNAKE_REACHES_FOOD_TESTS_H__
